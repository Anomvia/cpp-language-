			new and delete keyword in c++
=================================
sma-(static memory allocation)
dma-(dynamic memory allocation)
  
new --> By using new keyword we allocate memory
	 dynamically.
	 It allocate memory run time time and return adress 
	 of first byte.
	 Syntax-->
	                   new data_type;
	                   allocate  single block memory 
 			 new data_type[size]
 			 allocate memory blocks
 delete--> delete keyword is used to delete the memory
 		occupy by new keywords.
 		syntax--> delete  varname;
 		                delete single block memory'
 		                delete[] var
 		                delete multiple blocks.
 		                	
