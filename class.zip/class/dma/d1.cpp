#include<iostream>
using namespace std;
 int main()
 {
  int a=10;
 int *p1;
 float *p2;
 double *p3;
 p1=new int(10);
 p2=new float(12.3f);
 p3=new double(123.45);
 cout<<"\n Value of p1="<<*p1;
 cout<<"\n Value of p2="<<*p2;
 cout<<"\n Value of p3="<<*p3; delete p1;
 delete p2;
 delete p3;
cout<<"\n Value ofter Del ";
cout<<"\n Value of p1="<<*p1;
 cout<<"\n Value of p2="<<*p2;
 cout<<"\n Value of p3="<<*p3;
cout<<"\n \n Value of a="<<a;
  cout<<endl;
  }
