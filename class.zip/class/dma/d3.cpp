#include<iostream>
using namespace std;

int main()
{
 int num,num2,i;
 cout<<"\n pls enter memory sie";
 cin>>num;
 int *a=new int[num];
 cout<<"\n pls enter"<<num<<"-Array Elements";
 for(i=0;i<num;i++)
 {
 cin>>a[i];
  }
  cout<<"\n Array Elemetns are \n";
 for(i=0;i<num;i++)
 {
 cout<<"*"<<*(a+i);
  }
  //========================
  cout<<"\n pls enter new memory size";
  cin>>num2;
  cout<<"\n pls enter"<<num2<<"-Array Elements";
 for(i=num;i<num2+num;i++)
 {
 cin>>a[i];
  }
  cout<<"\n Array Elemetns are \n";
  int k=num2+num;
 for(i=0;i<k;i++)
 {
 cout<<"*"<<*(a+i);
  }
  
delete[] a;
  cout<<"\n Memory Deleted Successfully";

cout<<endl;
}


