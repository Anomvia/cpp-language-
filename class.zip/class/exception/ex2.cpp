#include<iostream>
using namespace std;
int main()
{
 int a,b,c;
 cout<<"\n pls enter a number for a";
 cin>>a;
 cout<<"\n pls enter an umber for b";
 cin>>b;
 if(b==0)
 {
 try
 {
  cout<<"Before exception block";
  cout<<"\n Before Throw block 2nd row";
  throw 0;
  cout<<"\n After  throw block";
  cout<<"\n After throw 2nd ";
 }catch(int a)
  {
  cout<<"\n Exception occure";
   }
 }else
 {
 c=a/b;
 cout<<"\n Result="<<c;
  }
  
 cout<<"\n This is first exp programm"<<endl;
}   
