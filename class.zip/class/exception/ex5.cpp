#include<iostream>
using namespace std;

int main()
{
 int num;
  cout<<"pls enter a number";
  cin>>num;
try
 {
  if(num==1)
  {
   throw 1;
   }
   if(num==2)
   { 
    throw 12.3f; 
   } 
   if(num==3)
   {
   throw 12.34;
   }
 }catch(...)
 {
  cout<<"\n Exception Occure" ;
 }
 cout<<"\n \n After try and catch" <<endl;
}//main 
