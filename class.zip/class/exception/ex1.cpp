#include<iostream>
using namespace std;
int main()
{
 int a,b,c;
 cout<<"\n pls enter a number for a";
 cin>>a;
 cout<<"\n pls enter an umber for b";
 cin>>b;
 if(b==0)
 {
 try
 {
  throw 0;
 }catch(int a)
  {
  cout<<"\n Division buy 0 is not possible";
   }
 }else
 {
 c=a/b;
 cout<<"\n Result="<<c;
  }
 cout<<"\n This is first exp programm"<<endl;
}   
