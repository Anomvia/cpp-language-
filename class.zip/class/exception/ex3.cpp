#include<iostream>
using namespace std;
int main()
{
 int a,b,c;
 cout<<"\n pls enter a number for a";
 cin>>a;
  if(a==0)
   {
     try
       {
       cout<<"\n Try block";
       throw 0;
       }catch(int a)
        {
         cout<<"\n Adition="<<10+20;
         cout<<"\n This is catch block";
         cout<<"\n Exceptio noccure";
            
         }
     }
}   

====================
try
{
}catch()   //allowed
  {
  }catch()
   {
   }catch()
   {
   }
   --------------------------------
   try
   {
   }try
   {
   }catch()  //Not allowed
   {
   }

