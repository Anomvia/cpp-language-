#include<iostream>
using namespace std;
class Demo
{
public:
Demo()
{
cout<<"\n Constructor called";
}
~Demo()
{
cout<<"\n Destructor Called";
}
};
int main()
{
Demo ob;
cout<<endl;
}
