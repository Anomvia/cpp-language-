		Destructor
=================================
Destructor is a member function which is used to deinitialize
the memory occupy by constructor.
   It is called automatically Before object delation.
        -->Constructor calll object first stage and destructor 
        called in last stage.
  ==>we declare destructor - class name follwed by tiled(~)
           operator.
          Note--> A constructoe can have parameter, wheare
                       as destrcutor never  have any parameter.
                       
                       
                       Syntax--> ~classname()
                              eg--> ~Demo()
                                        {
                                        }
                                        
                                          Demo()
                                           {
                                            }
                                            
                                           } 
                   
		
