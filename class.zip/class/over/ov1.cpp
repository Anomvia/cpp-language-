//Fun Overloading by changing number of argument
#include<iostream>
using namespace std;

class Demo
{
 public:
 void show(int a)
 {
  cout<<"\n Value of a="<<a;
 }
 void show(int a,int b)
 {
  cout<<"\n Value of a="<<a<<" "<<"value of b="<<b;
 }
 void show(int a,int b,int c)
 {
  cout<<"\n Adition of a+b+c+"<<a+b+c;
 }
 
};
int main()
{
Demo ob;
ob.show(12,12,23);
ob.show(12,34);
ob.show(23);
cout<<endl;
}
