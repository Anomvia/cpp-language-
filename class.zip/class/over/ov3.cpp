#include<iostream>
using namespace std;

class Demo
{
 public:
 void sum(int a,float b)
  {
   cout<<"\n Value ="<<a;
   }
   void sum(float f,int c)
   {
    cout<<"\n Float Value ="<<f;
    }
    void sum(double d)
    {
     cout<<"\n Value-"<<d;
    } 
};
int main()
{
Demo ob;
//ob.sum(10);
ob.sum(12.34f);
ob.sum(123.45);
cout<<endl;
}
