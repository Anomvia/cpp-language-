#include<iostream>
using namespace std;
class Demo
{
 public:
  void show()
  {
   cout<<"\n Hello from Demo show fucntion";
  } 
};
class Abc
{
 public:
  void show()
   {
   cout<<"\n Hello from Abc show fucntion";
   }
 };
 class xyz : public Demo,public Abc
 {
 };
 int main()
 {
 xyz ob;
 ob.Demo::show();
 ob.Abc::show();
 cout<<endl;
 }
