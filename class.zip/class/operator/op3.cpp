#include<iostream>
#include<string.h>
using namespace std;
class Demo
{
char data[20];
public:
void read()
{
cin>>data;
 }
 void disp()
  {
   cout<<"\n Data="<<data;
   }
   
   Demo operator +(Demo o)
   {
    Demo d;
   strcpy(d.data,data);
    strcat(d.data,"-");
    strcat(d.data,o.data);
    return d;
    }
    
 };
 int main()
 {
 Demo ob1,ob2,ob3;
 cout<<"\n pls neter value for ob1";
 ob1.read();
 cout<<"\n pls enter value for ob2";
 ob2.read();
 cout<<"\n ob1 data \n";
 ob1.disp();
 cout<<"\n ob2 data \n";
 ob2.disp();
 ob3=ob1+ob2;
 ob3.disp();
  cout<<endl;
  }
