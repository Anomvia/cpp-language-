	
			Operator Overloading
=================================

 When same operator play different different role is 
 known as operator overloading.
 
   Note --> By using operator overloading we are not
                   going to create a new operator.
             We only asssign a new task to existing operator.
      syntax->
       
          return_type fun_name(argumnet)
          { 
          } 
        
        eg-->
             void operator ++()
             { 
             }  
          
       =>Name of operatoe that we can,t overload.
       ==============================
       1-scope_resolution op (::)
       2-sizeof operator
       3- Dot operaotr(.)
       4- &
       5-conditional operator(? :)
       
       
       ==> ++ -- ++a  --b
      a+b a-b      <     q?q :q:    
