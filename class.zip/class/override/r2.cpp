#include<iostream>
using namespace std;
class Demo
{
 public:
  void show()
  {
   cout<<"\n Hello from Super Demo";
   }
 };
 class Abc :public Demo
 {
  public:
   void show()
   {
   cout<<"\n Hello from Sub Abc";
   } 
  };
 class xyz : public Abc
 {
  public:
  void show()
   {
   cout<<"\n Hello from sub xyz";
    } 
  } ;
  int main()
  {
  Demo *p;
   xyz ob;
   p=&ob;
   p->show();
   Abc ob2;
   p=&ob2;
  p->show();
  cout<<endl;
  }
  
