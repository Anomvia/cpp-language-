#include<iostream>
using namespace std;
class Demo
		{
		//string name;
		char name[20];
		public:
	void read()
	{
 		cout<<"\n pls enteer name";
 		cin>>name;
 	}
 	void demoshow()
 	{
 		cout<<"\n Name="<<name;
 	} 
};

class sub1 : public Demo 
{
 		int id;
 		public:
 		void read1()
 	{
 		cout<<"\n pls enter id";
 		cin>>id;
 	}
 	void sub1show()
 	{
 		cout<<"\n Id="<<id;
 	}
 };
 
 class sub2 : public Demo
 {
 int pass;
 public:
 void read2()
 {
 cout<<"\n pls enter pass";
 cin>>pass;
  }
  void sub2show()
  {
  cout<<"\n pass="<<pass;
  }
 };
 int main()
 {
  sub1 s1;
 sub2 s2;
 s1.read();
 s1.read1();
 s1.demoshow();
 s1.sub1show();

 s2.read();
 s2.read2();
 s2.demoshow();
 s2.sub2show();

 cout<<endl;
 }
