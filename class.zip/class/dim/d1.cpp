#include<iostream>
using namespace std;
class Demo
{
 public:
  void show()
  {
   cout<<"\n Hello from Base class Demo";
   }
 };
 class sub1 : virtual  public Demo
 {
  };
  class sub2 : virtual public Demo
  {
  };
  
 class Abc : public sub1 , public sub2
 {
 };
 
 int main()
 {
 Abc ob;
 ob.show();
 cout<<endl;
 } 
