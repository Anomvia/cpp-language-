#include<iostream>
using namespace  std;
class Demo
{
public:

void show()
{
 cout<<"\n Hello from show";
 }
 
 virtual void disp1()=0;
 virtual void disp2()=0;

};
class Abc : public Demo
{
 public:
  void disp1()
  {
    cout<<"\n Hello from dsip1";
   }
};
class xyz : public Abc
{
public:
void disp2()
{
 cout<<"\n Hell ofrom disp2";
 }
};
int main()
{
 xyz ob;
 ob.show();
 ob.disp1();
 ob.disp2();
cout<<endl;
}       
