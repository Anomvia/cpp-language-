#include<iostream>
using  namespace std;

 class Demo
 {
  int pizza;
  public:
  void setPizza(int p)
   {
    pizza=p;
   }
   int getPizza()
   {
    if(pizza<=5)
     {
      cout<<"Alert!!!!! ";
      cout<<"\n Pizza stock  is going to low stock categry";
      cout<<"\n Pls make order";
      return pizza;
     }else
     {
    return pizza;
     }
   }  
 };
 int main()
 {
  Demo ob;
   int a=4,k;
  ob.setPizza(a);
  k=ob.getPizza();
  cout<<"\n Pizza Stock is="<<k;
   cout<<endl;
 }
 
