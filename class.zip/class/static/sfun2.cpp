#include<iostream>
using namespace std;

class Demo
{
 public:
  int a;
  static int b;
  Demo()
  {
   a=20;
  }
  static void disp()
  {
  //cout<<"\n Value of a="<<a;
  cout<<"\n Value of b="<<b;
  }
};
int Demo::b=10;
int main()
{
Demo::disp();
 cout<<endl;
}
