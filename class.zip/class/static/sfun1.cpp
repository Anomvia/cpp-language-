#include<iostream>
using namespace std;
class Demo
{
public:
void show()
{
 cout<<"\n Non Static function";
 }
static void disp()
 {
 cout<<"\n Static function";
 }
};
int main()
{
//Demo::show();
Demo::disp();
Demo ob;
ob.show();
cout<<endl;
}
