#include<iostream>
using namespace std;

template<typename myt>
void check(myt a,int b)
{
  if(a>b)
  {
  cout<<a;
   }else
   {
    cout<<b;
    }
    cout<<endl;
 }
 int main()
 {
 check(12,23.56);
 check(12.34,15.34f);
 check('A','d');
 cout<<endl;
 }
