#include<iostream>
using namespace std;

template<typename myt>void check(myt a=2,myt b=1)
{
  if(a>b)
  {
  cout<<a;
   }else
   {
    cout<<b;
    }
    cout<<endl;
 }
 int main()
 {
 check(12);
 //check();
 check('d');
 cout<<endl;
 }
