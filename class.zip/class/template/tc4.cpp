#include<iostream>
using namespace std;
template<class m1,class m2=int>class Abc
{
 m1 a;
 m2 b;
 public:
 Abc(m1 k,m2 l)
 { 
 a=k;
 b=l;
 }
 void show()
  {
   cout<<"\n Value of a="<<a;
   cout<<"\n Value of b="<<b;
   }
 };
 int main()
 {
 Abc<double> ob1(10,20.12);
  Abc<int> ob2(12.3f,45.56);
  ob1.show();
  ob2.show();
  cout<<endl;
  }
