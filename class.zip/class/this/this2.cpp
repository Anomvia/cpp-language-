#include<iostream>
using namespace std;
class Demo
{
  int id,pass;
   public:
    void read(int id,int pass)
     { 
     
        this->id=id;
        this->pass=pass;
      }
      void disp()
      {
        cout<<"\n Id="<<id;
        cout<<"\n Pass="<<pass;
       }
 };
  int main()
  {
  Demo ob;
  ob.read(101,1234);
  ob.disp();
  cout<<endl;
   }
