#include<iostream>
using namespace std;
int main()
{
 int a;
 char s;
 cout<<"\n pls enter a number";
 cin>>a;
 cout<<"\n pls enter char val";
 cin>>s;
 cout<<"\n char val="<<s;
 if(a>=18)
 {
  cout<<"\n You are valid for vote";
  }else
  {
   cout<<"\n Sorry u r not valid for vote pls wait";
   }
  cout<<endl;
}
