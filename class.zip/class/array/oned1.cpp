#include<iostream>
 using namespace std;
 int main()
 {
   int a[5];
    int i;
    cout<<"\n pls enter array elemetns";
     for(i=0;i<5;i++)
      {
       cin>>a[i];
       }
     cout<<"\n Array Elemtns are ";
      for(i=0;i<5;i++)
       {
        cout<<" "<<a[i];
        }  
   cout<<endl;
  }
