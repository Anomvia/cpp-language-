
				File Handling
=================================
-File is collection of byte.
-File handling is a concept by whcih we store our data 
permanently in secondary storage.
-File will take place in secondary storage device.

Advantage OF file
==================
1-Save dat permanent.
2-We can eaisily transfer input and out data from one 
    computer to another.
  
  Note --> For file handling operation we have to use 
                 "fstream" library file.
      c++ provide followinf classes for file handling operation
                 
    Some importtant function
    ==============
    1- open() -use to open a file
    2-close()_ use to close a file
    3-getline() -use to read data.
    4-good() -return true untill dta present in file
    
    file mode
   ---------------------
   File mode define intenstion to open a file.
   ios::out --> open a file in write mode
                     (it is by default available inside ofstream).
  ios::in -->open the file in read mode 
  		 (it is by default available inside ifstream).
  ios::app -->USe to append data
  ios::ate -->use to append data(but by using this we can
   overrdie  data).		 
  
  Note-->fstream can perfrom both(r+w) operation that,s
        why inside this by default both mod(ios::in and ios::out)
               is avaialble.
         -->Inside file handling we perform following operation.
               1-open or create a file
               2-writing in file  
               3-read from file.
               4-close a file
               
