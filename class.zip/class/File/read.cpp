#include<iostream>
#include<fstream>
using namespace std;
int main()
{
ifstream file("write.cpp",ios::in);
if(!file.is_open())
{
 cout<<"\n File is not open";
 }else
 {
   string s;
  while(file.good())
  {
   getline(file,s);
   cout<<s;
    }
 } 
  cout<<endl;
}
