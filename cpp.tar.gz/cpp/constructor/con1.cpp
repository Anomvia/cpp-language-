#include<iostream>
using namespace std;
class Demo
{
 int num;
 public:
 Demo()  //Default Constructor
 {
  num=1;
  cout<<"\n Default Constructor Created";
 }
 public:
 void show()
 {
 cout<<"\n Value of num="<<num;
 }
};
int main()
{
Demo ob;
ob.show();
cout<<endl;
}
