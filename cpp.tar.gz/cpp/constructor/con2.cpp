#include<iostream>
using namespace std;
class Demo
{
 int num;
 public:
 Demo(int a)  //Parameterised Constructor
 {
  num=a;
  cout<<"\n Parameterised Constructor Created";
 }
 public:
 void show()
 {
 cout<<"\n Value of num="<<num;
 }
};
int main()
{
Demo ob1(10);
Demo ob2(20);
Demo ob3(30);
ob1.show();
ob2.show();
ob3.show();
cout<<endl;
}

