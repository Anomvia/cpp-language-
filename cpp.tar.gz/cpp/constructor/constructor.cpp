			Constructor
=================================
Constructor is a special member function whcih is call
 automatically, When object is created.
     Constructor is used to initialize the object.
  Constructor declare in public area.
 
  Rule for Define Constructor
  ======================   
 1-->Constructor name and class name should be same.
 2-->Constructor never have retrutn type.
 
 ==>Types of Constructor
 =======================
 1-Default Constructor
 2-Parameterised Constructor
 3-Copy Constructor
 
 1-->Default Construtor --> The constructor which does not
 					    have argumnet is known as 
 					    default construtor.
 -->Default constructor are two types-
    1-System Defined--> When we not create any constructor 
                                      in program then compiler create
                                      default constructor. 
    2-USer defined-->   User defiend is created by user.
      
      Note-->When we create any constructor in our program
      		   at that time compiler does,t create any 
      		   constructor.
      		   
                            
