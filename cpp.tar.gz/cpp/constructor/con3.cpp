#include<iostream>
using namespace std;
class Demo
{
 public:
 Demo(int a)  
 {
   cout<<"\n  Single int cons running="<<a;
 }
 Demo(int a,int b)
 {
  cout<<"\n Double int Con running="<<a<<" "<<b; 
 }
};
int main()
{
Demo ob1(10);
Demo ob2(20,30);
cout<<endl;
}

