#include<iostream>
using namespace std;
class Demo
{
 public:
 ~Demo()
 {
  cout<<"\n Destructor called \n";
 }
 Demo()
 {
  cout<<"\n Default Constructor";
 }
 Demo(int b)
 {
  cout<<"\n Parameterised Constructor";
 }
 
};
int main()
{
Demo ob1;
Demo ob2(10);
cout<<endl;
}
