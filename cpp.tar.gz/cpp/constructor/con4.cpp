#include<iostream>
using namespace std;
class Demo
{
 int num;
 public:
 Demo(int a)
 {
  num=a;
 }
 Demo(Demo &ob)
 {
  num=ob.num;
 }
 void show()
 {
 cout<<"\n Value of num="<<num;
 }
};
int main()
{
Demo ob1(10);
ob1.show();
Demo ob2(ob1);
ob2.show();
cout<<endl;
}
