
				Inheritance
================================
 Inheritance is proceses of creating  a new class by using 
 existing class.
   Inheritance is feature of oops.
 -In inheritance we inherit propertieds and behaviour of
   one class to another class.
  --> The class from which we inherit the properties is known 
       as super/base/parrent class.
                              -The class which inherit the properties is 
       known as sub/derived/child class.
       
      synatx-->
                  sub_className : visibility_mode Super class name
                       
      Types Of Inheritance
      ===============
      In c++ there are 5 types of inheirtance, which is-
      
      1-Single inheritance
      2-Multiple inheritance
      3-Multilevel Inheritance
      4-Hierarchical Inheritanc
       5-Hybrid Inheritance
       
1-Single Inheritance -->In Single level inheritance  a sub class
				    is derived from a single super class.
				        
2-> Multiple Inheritance -> When a sub class is derived from more than
                                           more than one super class is
                                           known as multiple inheritance.
3->Multi Level Inheritance-->When a class is derved from a
 class which is already derived from another class and (such 
  type of class is knwon as intermediate sub class) is 
  called multilevel inheritance.
  
  4-->Hirarchical Inheritance --> When more than one sub 
  						class is derived from same 
  super class is known as hierarchical inheritance.
  
  5-->Hybrid Inheritance --> Hybrid inheritance is 
  					combination  of more than one 
  					inheritance.
  					
                            
   				        
