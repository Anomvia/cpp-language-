#include<iostream>
using namespace std;
class External
{
public:
 int ext;  //data member 
 void read()
 {
 cout<<"\n Pls enter external mark's";
 cin>>ext; 
 }
};

class Internal
{
public:
int intr;
public:
void read2()
{
cout<<"\n pls enter internal Marks";
cin>>intr;
}
};

class Total : public Internal , public External
{
public:
 void total()
 {
 cout<<"\n Total Marks="<<intr+ext;
  }
 };
int main()
{
Total ob3;
ob3.read();
ob3.read2();
ob3.total();
cout<<endl;
}


/*
class A
{
};
class B : A
{
};
class C: B
{
}
class D:C
{
}
*/
/*
 class A
 {
 }
 
 class B : A
 {
 }
 class C : A
 {
 }
