#include<iostream>
using namespace std;

class Demo
{
public:
void show()
{
 cout<<"\n Hello from super class Show()";
}
};


class Abc : public Demo 
{
public:
 void check()
 {
 cout<<"\n Hello from sub class Abc chaeck()";
  }
};

int main()
{
Abc ob;
ob.check();
ob.show();	
cout<<endl;
}
