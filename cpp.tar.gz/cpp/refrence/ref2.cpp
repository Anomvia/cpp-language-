#include<iostream>
using namespace std;

int main()
{
 int a=10;
 int &r=a;
 int *p=&a;
 cout<<"\n Value of r="<<r;
 cout<<"\n Value of p="<<*p;
  //r++ ;
 //(*p)++ ;
 cout<<"\n Value of r and p after Increment";
cout<<"\n Value of r="<<++r;
 cout<<"\n Value of p="<<++(*p)<<endl; 
 }
