#include<iostream>
using namespace std;
class Abc;
class Demo
{
int num1;
public:
void read()
{
cout<<"\n pls enter value";
cin>>num1;
}
void demoshow()
{
 cout<<"\n Value of Demo num1="<<num1;
 }
 friend void operator>(Demo ,Abc);
};
class Abc
{
int num2;
public:
void read()
{
 cout<<"\n pls enter a number";
 cin>>num2;
 }
 void abcshow()
 {
 cout<<"\n Value of Abc num2="<<num2; 
 }
 friend void operator >(Demo,Abc);
};
void operator >(Demo d,Abc a)
{
  if(d.num1>a.num2)
   {
   cout<<"\n Demo num1 is greater";
    }
    else if(a.num2>d.num1) 
    {
     cout<<"\n Abc num2 is greater";
     }
      else
      {
       cout<<"\n Both Demo num1 and Abc num2 is same"; 
      }
 }

int main()
{
Demo ob1;
Abc ob2;
ob1.read();
ob2.read();
ob1.demoshow();
ob2.abcshow();
ob1>ob2;
cout<<endl;
 }
