#include<iostream>
using namespace std;
class Demo
{
int a;
public:
void read()
{
cin>>a;
}
void disp()
{
cout<<"\n Value of disp()="<<a;
 }
 void operator >(Demo o)
 {
  if(a>o.a)
  {
  cout<<"\n ob1 a is grater";
   }
   else if(o.a>a)
   {
   cout<<"\n Ob2 a is greater";
    }else
    {
    cout<<"\n Both ob1 and ob2 are same";
    }
  }
 };
 int main()
 {
 Demo ob1,ob2;
 cout<<"\n pls enter Ob1 value";
 ob1.read();
 cout<<"\n pls neter value for ob2";
 ob2.read();
 ob1.disp();
 ob2.disp();
  ob1>ob2;
  cout<<endl;
  }
