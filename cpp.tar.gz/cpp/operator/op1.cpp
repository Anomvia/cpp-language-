#include<iostream>
using namespace std;
class Abc
{
 int a;
 public:
 void read()
 {
  cout<<"\n Pl senter value of a";
  cin>>a;
  }
 void disp()
 {
  cout<<"\n Value of a="<<a;
  } 
  void operator ++()
  {
   ++a;
  }
  void operator --()
   {
   --a;
   }
};
int main()
{
Abc ob;
ob.read();
ob.disp();
++ob;
ob.disp();
--ob;
ob.disp();
 cout<<endl;
 }
