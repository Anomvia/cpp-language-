#include<iostream>
using namespace std;
template<class m>class Abc
{
 m a;
 m b;
 public:
 Abc(m k,m l)
 { 
 a=k;
 b=l;
 }
 void show()
  {
   cout<<"\n Value of a="<<a;
   cout<<"\n Value of b="<<b;
   }
 };
 int main()
 {
 Abc<int> ob1(10,20);
  Abc<float> ob2(12.3f,45.2f);
  ob1.show();
  ob2.show();
  cout<<endl;
  }
