#include<iostream>
using namespace std;

template<typename myt>void check(myt a,myt b)
{
  if(a>b)
  {
  cout<<a;
   }else
   {
    cout<<b;
    }
    cout<<endl;
 }
 int main()
 {
 check(12,23);
 check(12.34,10.34);
 check('A','d');
 cout<<endl;
 }
