#include<iostream>
using namespace std;

class  First
{
public:
 void show()
 {
   cout<<"\n First class(oops) Programm:";
  }
};
int main()
{
 First ob;
 ob.show();
 cout<<endl;
}

