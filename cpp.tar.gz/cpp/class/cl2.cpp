#include<iostream>
using namespace std;
class Demo
{
 int a,b;
  public:
  void read()
   {
    cout<<"\n pls enter two number";
     cin>>a>>b;
    }
     void add()
     {
      cout<<"\n Result="<<a+b;
      }
};
 int main()
  {
   Demo ob;
   ob.read();
   ob.add();
   cout<<endl;
  }
