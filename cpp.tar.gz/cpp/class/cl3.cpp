#include<iostream>
using namespace std;
class Demo
{
 int k,l;
 public:
  int read(int a,int b)
  {
    return a+b;
      }
   };
 int main()
 {
  int a,b;
  Demo ob;
  cout<<"\n pls enter two number";
  cin>>a>>b;
 int k= ob.read(a,b);

 cout<<"\n Adition="<<k;
  cout<<endl;
 }
