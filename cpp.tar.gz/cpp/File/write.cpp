#include<iostream>
#include<fstream>
using namespace std;
int main()
{
ofstream file("abc.txt",ios::out|ios::app);
if(!file.is_open())
{
 cout<<"\n File is not open";
 }else
 {
  file<<"Hello class .....";
  file<<"\n This is First file programm";
  }
  cout<<"\n File written successfully"<<endl;
}
