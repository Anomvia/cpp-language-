#include<iostream>
#include<fstream>
using namespace std;
int main()
{
 fstream file("abc.txt",ios::out|ios::in);
if(!file.is_open())
{
 cout<<"\n File is not open";
 }
 else
 {
  file<<"Hello class .....";
  file<<"\n This is First file programm";
  }
  file.seekg(0);
  cout<<"\n File Data is="<<endl;
  string s;
  while(file.good())
  {
   getline(file,s);
   cout<<s;
    } 
  cout<<endl;
}

