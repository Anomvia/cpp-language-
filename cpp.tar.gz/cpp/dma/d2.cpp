#include<iostream>
using namespace std;
int main()
{
int *p=new int;
float *f=new float;
 *p=21;
 *f=23.5f;
 cout<<"\n Value of p="<<*p;
  cout<<"\n Value of  f="<<*f;
  delete p;
  delete f;
 cout<<endl;
}
