
			Exception Handling in c++
==================================
-Exception is a event  that termiantes programm abnormally.
-Exception is unwanted, unexpected error, that detrupts
   normal flow of execution.
   
    Advantage of Error-  If we don't handle exception and 
    				     if any exception occure in our program
    				     then our program will terminate
    abnormally but if we have handle the exception then 
    compiler will throw the error and execute rest of the code.
     
     ================================
    Error are two type,s
   -compile time error- Compile time error occure due to 
                                   syntax error.
  -runtime Error- Runtime error occure due to logical error.
			    It is also known as exception.
			    eg--> Int a  //syntax error
			        -10/0;
			        -int arr[5];  DevideByZeroException
			         cout<<a[7];
			         ArrayIndexOutOfBoundException
			         
====================================
  C++ support exceptio nhandling and c++ provide readymade 
   support for exception handling.
    
 To handle a exception c++ provide 3 keywords.
  1-try
  2-throw 
  3-catch
  1-try --> Inside try block we write the code that we want to 
                 monitor.
 2-throw --> IT is used inside try block, When exception 
 		occure inside try block then it throw the exception
 		by using throw keyword.
 3- catch --> Inside catch block we write the exception 
 		handling code. It is used to handle exception.
 
  Note--> A try block should follow at least one catch block.
  
  Syntax-->
       
       try
       {
       //logic
       throw Exception.
       }
       cout<<djfhdsfh//Not allowed
       catch(Exception)
        {
        }
                    		 
 Note--> No entermediate code allow between try and catch 
 		block.
 
  
