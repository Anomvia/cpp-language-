#include<iostream>
using namespace std;
class Demo
{
 int num;
 public:
 void setNum(int a)
 {
   num=a;
  }
  int getNum()
   {
    return num;
   }
   
 };
 int main()
 {
  Demo ob;
  int a,k;
  cout<<"\n pls enter value";
  cin>>a;
  ob.setNum(a);
  k=ob.getNum();
  cout<<"\n Value of num="<<k; 
  cout<<endl;
 }

