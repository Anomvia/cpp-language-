#include<iostream>
using namespace std;
 
 int main()
 {
  int a,b,c,d;
  cout<<"\n pls enter two  number";
  cin>>a>>b;
 // cout<<"\n pls enter sec value ";
  //cin>>b;
  c=a+b;
  d=a*b;
  cout<<endl<<" Adition="<<c<<endl;
  cout<<"Multiplication="<<d<<endl;
 }
 
