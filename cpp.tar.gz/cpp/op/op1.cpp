#include<iostream>
using namespace std;

int main()
{
   int a=9;
   cout<<a++; 9--- 10
    a++;            -----11
    
   cout<<a; 11---11
   cout<<a--;11---10
   a--;               ----9
   cout<<a--;  9---8
   cout<<a;    8----8
   cout<<endl; 
 }
 
 //10 8 
