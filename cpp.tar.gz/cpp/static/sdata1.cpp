#include<iostream>
using namespace std;
class Demo
{
 public:
 static int num;
 public:
 void count()
  {

    cout<<" "<<num;
    num++;
    }
 };
 int Demo::num=1;

 int main()
 {
 Demo ob1,ob2,ob3;
 ob1.count();
 ob2.count();
 ob3.count();
 
 Demo::num=20;
 cout<<"\n Value of num="<<Demo::num;
 
 cout<<endl;
  }
