#include<iostream>
using namespace std;
class Demo
{
 public:
 virtual void show()=0;
 void disp()
 {
  cout<<"\n Hell ofrom Demo disp";
  }
};
class Abc : public Demo
{
 public:
 void show()
 {
  cout<<"\n Now this is complete fun";
  }
};

int main()
{
Abc ob;
ob.show();
 ob.disp();
 cout<<endl;
 }
