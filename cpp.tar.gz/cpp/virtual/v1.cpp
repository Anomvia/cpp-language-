#include<iostream>
using namespace std;
class Demo
{
 public:
virtual void show()
 {
 cout<<"\n Hello from Demo show";
 }
};
class Abc : public Demo
{
 public:
  void show()
   {
   cout<<"\n Hello from Abc show";
  } 
};
class xyz : public Abc
{
public:
 void show()
{
 cout<<"\n Hello from xyz show"; 
 }
};

int main()
{
Demo *p;
Abc  ob1;
p=&ob1;
p->show();

xyz ob2;
p=&ob2;
p->show();
cout<<endl;
}

