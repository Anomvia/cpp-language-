#include<iostream>
using namespace std;

struct emp
{
 int id;
 float sal;
 char name[20];
 
 void read()
 {
  cout<<"\n pls enter emp id,name and salary";
  cin>>id>>sal>>name;
 }
 
 void disp()
  {
  
  cout<<"\n Employee Detail ";
  cout<<"\n Emp id="<<id;
  cout<<"\n Emp Name="<<name;
  cout<<"\n Emp Salary="<<sal<<endl;
  }
};

 int main()
 {
  //emp e;
 emp e;
 e.read();
 e.disp();
 cout<<endl;
 }
