#include<iostream>
using namespace std;
struct emp
{
  int id;
  char name[20];
  float sal;
};

struct emp read()
{
 struct emp e;
 cout<<"\n pls enter id name and salary";
 cin>>e.id>>e.name>>e.sal;
 return e;
}

void disp(struct emp e1)
{
 cout<<"\n Employee Detail";
 cout<<"\n Employee id="<<e1.id;
 cout<<"\n Employee Name="<<e1.name;
 cout<<"\n Employee Sal="<<e1.sal;
} 
int main()
{
struct emp k;
 k=read();
 disp(k);
 cout<<endl;
}
