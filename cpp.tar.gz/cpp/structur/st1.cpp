#include<iostream>
using namespace std;
struct emp
{
 int id;
 float sal;
 char name[20];
};
int main()
{
 struct emp e1;
 cout<<"\n pls enter emp id salary and name";
 cin>>e1.id>>e1.sal>>e1.name;
 cout<<"\n Employee Details \n";
 cout<<"\n EMployee Id="<<e1.id;
 cout<<"\n Employee Salary="<<e1.sal;
 cout<<"\n Employee Name="<<e1.name<<endl; 
 }
 
 
