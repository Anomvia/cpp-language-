#include<iostream>
using namespace std;
class Demo
{
 public:
  void show()
  {
   cout<<"\n Hello from Super Demo";
   }
 };
 class Abc :public Demo
 {
  public:
   void show()
   {
   cout<<"\n Hello from Sub Abc";
   } 
  };
  int main()
  {
  Abc ob;
  ob.show();
  cout<<endl;
  }
  
