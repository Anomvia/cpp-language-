
			c++
============================
 c++ object oriented computer programing 
 language developed by Mr. Byan Stroustrup at
  At & T Bell Telephone Laboratry in 1982.
 
c++ is superset or extension of c-language.

c++ is also known as hybrid language because it
 support both(pop nad oops) concept,s. 
  and that why c++ is known as pure object 
  oriented programming language.
  
  ==========================
    Application of c++ -->
    
    1-->Compiler ,interpreter are develop by
      using c++.
     2-Fire fox browser is developed by using c++.
     3-multiple database are designed in c++.
 ===========================
 
 Features of c++
 ------------------------
 
 1-simple -->
 2-Platform Dependent.
 
 A language is said to be platform dependent
  when  it run on same platform inwhich it is
  designed and compile is known as platform 
  dependent languge.
   eg--> c,c++
   
   3- portable-->
   We can easily trafer  c++ code from one machine
    to another machine.
   
   4-object orinted programing(oops)-->
   c++ support object oriented concept.
   
  Features of oops-->
  1-class
  2-object
  3-Abstraction
  4-Encapsulation
  5-Polymorphism
  6-Inheritance
  
  5-case sensitive ->
  c++ is case sensitive language
   A language is said to be case sensitive when 
   it treats lower case and upper case sepratly
   is known as case sensitive  language.
   eg--> int a,A;
       here both consider as two different variable.
    
     ==>Case Insensitive--> html ,sql.
        eg--> <html> <HTML>
        
   6--> pointer -->
    pointer is variable that stores address of another
    variable.
    
     and c++ support pointer.
     
     ========================
     
      
