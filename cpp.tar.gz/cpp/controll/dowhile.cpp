#include<iostream>
using namespace std;
int main()
{
  int i=1;
  do
  {
    cout<<"\n Hello class";
     i++;
   }while(i<=10);
   
cout<<endl;
}   
