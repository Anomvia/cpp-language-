#include<iostream>
using namespace std;

 int main()
 {
  int a[3][3];
  int i,j;
  cout<<"\n Enter array elemtns ";
   for(i=0;i<3;i++)
    {
      for(j=0;j<3;j++)
       {
         cin>>a[i][j];
        }
     } 
     //print arrary
    cout<<"\n Array Elemtns are \n";
     for(i=0;i<3;i++)
    {
      for(j=0;j<3;j++)
       {
         cout<<a[i][j];
        }
        cout<<endl;
     } 
    cout<<endl;    
  }
